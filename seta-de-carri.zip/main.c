/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int main() {

  int e_nro_1, e_nro_2, e_nro_3; 

  printf("Digite o 1° número: ");
  scanf("%i", &e_nro_1);

  printf("Digite o 2° número: ");
  scanf("%i", &e_nro_2);

  printf("Digite o 3° número: ");
  scanf("%i", &e_nro_3);

  if(e_nro_1 > e_nro_2){
    if(e_nro_2 > e_nro_3){
      printf ("%i\n", e_nro_3);
      printf ("%i\n", e_nro_2);
      printf ("%i\n", e_nro_1);
    }
    else if(e_nro_1 > e_nro_3){
      printf ("%i\n", e_nro_2);
      printf ("%i\n", e_nro_3);
      printf ("%i\n", e_nro_1);
    }
    else{
      printf ("%i\n", e_nro_2);
      printf ("%i\n", e_nro_1);
      printf ("%i\n", e_nro_3);
    }
  }

  else if(e_nro_1 > e_nro_3){
      printf ("%i\n", e_nro_3);
      printf ("%i\n", e_nro_1);
      printf ("%i\n", e_nro_2);
  }
  else if(e_nro_2 > e_nro_3){
      printf ("%i\n", e_nro_1);
      printf ("%i\n", e_nro_3);
      printf ("%i\n", e_nro_2);
  }
  else {
      printf ("%i\n", e_nro_1);
      printf ("%i\n", e_nro_2);
      printf ("%i\n", e_nro_3);
  }

  return 0;
}
}
