/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

typedef struct {
    int matricula;
    char nome;
    float nota1;
    float nota2;
} Aluno;

int main(){
    Aluno aluno
    aluno.matricula = 20138;
    strncpy = Maria Bonita;
    aluno. = 8,0;
    aluno. = 9,0 ; \\
    printf("\n%d %5 %1.2f %1.2f",);
    
    return 0;
}
